﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssignmentWeek4
{
    public partial class Form1 : Form
    {
        List<Team> teamList = new List<Team>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Player> juventusPlayers =  new List<Player>();
            Team juventusTeam = new Team("Juventus", "England", "Jakarta", juventusPlayers);
            teamList.Add(juventusTeam);
            juventusPlayers.Add(new Player("Wojciech Szczęsny", "1", "GK"));
            juventusPlayers.Add(new Player("Mattia De Sciglio", "2", "DF"));
            juventusPlayers.Add(new Player("Bremer", "3", "DF"));
            juventusPlayers.Add(new Player("Manuel Locatelli", "5", "MF"));
            juventusPlayers.Add(new Player("Danilo", "6", "DF"));
            juventusPlayers.Add(new Player("Federico Chiesa", "7", "FW"));
            juventusPlayers.Add(new Player("Weston McKennie", "8", "MF"));
            juventusPlayers.Add(new Player("Dušan Vlahović", "9", "FW"));
            juventusPlayers.Add(new Player("Paul Pogba", "10", "MF"));
            juventusPlayers.Add(new Player("Juan Cuadrado", "11", "MF"));
            juventusPlayers.Add(new Player("Alex Sandro", "12", "DF"));
            juventusPlayers.Add(new Player("Arkadiusz Milik", "14", "FW"));
            
            List<Player> manchesterUnitedPlayers = new List<Player>();
            Team manchesterUnitedTeam = new Team("Manchester United", "England", "Surabaya", manchesterUnitedPlayers);
            teamList.Add(manchesterUnitedTeam);
            manchesterUnitedPlayers.Add(new Player("David de Gea", "1", "GK"));
            manchesterUnitedPlayers.Add(new Player("Victor Lindelöf", "2", "DF"));
            manchesterUnitedPlayers.Add(new Player("Phil Jones", "4", "DF"));
            manchesterUnitedPlayers.Add(new Player("Harry Maguire", "5", "DF"));
            manchesterUnitedPlayers.Add(new Player("Lisandro Martínez", "6", "DF"));
            manchesterUnitedPlayers.Add(new Player("Bruno Fernandes", "8", "MF"));
            manchesterUnitedPlayers.Add(new Player("Anthony Martial", "9", "FW"));
            manchesterUnitedPlayers.Add(new Player("Marcus Rashford", "10", "FW"));
            manchesterUnitedPlayers.Add(new Player("Mason Greenwood", "11", "FW"));
            manchesterUnitedPlayers.Add(new Player("Tyrell Malacia", "12", "DF"));
            manchesterUnitedPlayers.Add(new Player("Christian Eriksen", "14", "MF"));
            manchesterUnitedPlayers.Add(new Player("Marcel Sabitzer", "15", "MF"));
            
            List<Player> manchesterCityPlayers = new List<Player>();
            Team manchesterCityTeam = new Team("Manchester City", "Indonesia", "Ujung Pandang", manchesterUnitedPlayers);
            teamList.Add(manchesterCityTeam);
            manchesterCityPlayers.Add(new Player("Kyle Walker", "2", "DF"));
            manchesterCityPlayers.Add(new Player("Rúben Dias", "3", "DF"));
            manchesterCityPlayers.Add(new Player("Kalvin Phillips", "4", "MF"));
            manchesterCityPlayers.Add(new Player("John Stones", "5", "DF"));
            manchesterCityPlayers.Add(new Player("Nathan Aké", "6", "DF"));
            manchesterCityPlayers.Add(new Player("İlkay Gündoğa", "8", "MF"));
            manchesterCityPlayers.Add(new Player("Erling Haaland", "9", "FW"));
            manchesterCityPlayers.Add(new Player("Jack Grealish", "10", "MF"));
            manchesterCityPlayers.Add(new Player("Aymeric Laporte", "14", "DF"));
            manchesterCityPlayers.Add(new Player("Rodri", "16", "MF"));
            manchesterCityPlayers.Add(new Player("Kevin De Bruyne", "17", "MF"));
            manchesterCityPlayers.Add(new Player("Stefan Ortega", "18", "GK"));
            refreshCBCountry();
        }

        private Team getCurrentTeam() {

            if (cbTeam.SelectedItem == null)
            {
                MessageBox.Show("Team not selected yet");
                return null;
            }
            Team selectedTeam = null;
            foreach (Team team in teamList)
            {
                if (cbTeam.SelectedItem.Equals(team.TeamName))
                {
                    selectedTeam = team;
                    break;
                }
            }
            return selectedTeam;
        }

        private void cbCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbTeam.Items.Clear();
            ComboBox cb = sender as ComboBox;
            foreach (Team team in teamList)
            {
                if (cb.SelectedItem.Equals(team.TeamCountry))
                {
                    cbTeam.Items.Add(team.TeamName);
                }
            }
        }
        private void refreshCBCountry()
        {
            cbCountry.Items.Clear();
            foreach (Team team in teamList)
            {
                if (!cbCountry.Items.Contains(team.TeamCountry))
                {
                    cbCountry.Items.Add(team.TeamCountry);
                }
            }
        }
        private void refreshTeamMember(ComboBox cb) {
            lbTeamMember.Items.Clear();
            foreach (Team team in teamList)
            {
                if (cb.SelectedItem.Equals(team.TeamName))
                {
                    foreach (Player player in team.GetPlayers)
                    {
                        lbTeamMember.Items.Add(player.ToString());
                    }
                }
            }
        }
        private void cbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;
            refreshTeamMember(cb);
        }

        private void btnAddTeam_Click(object sender, EventArgs e)
        {
            if (tbTeamCity.Text.Equals("") || tbTeamCountry.Text.Equals("") || tbTeamName.Text.Equals(""))
            {
                MessageBox.Show("You need to fill all the team fields");
                return;
            }
            foreach (Team team in teamList)
            {
                if (team.TeamName.ToUpper().Equals(tbTeamName.Text.ToUpper()))
                {
                    MessageBox.Show("Team already exists");
                    return;
                }
            }
            teamList.Add( new Team(tbTeamName.Text, tbTeamCountry.Text, tbTeamCity.Text) );
            refreshCBCountry();
        }

        private void btnAddPlayer_Click(object sender, EventArgs e)
        {
            if (tbPlayerName.Text.Equals("") || tbPlayerNumber.Text.Equals("") || cbPlayerPosition.SelectedItem==null)
            {
                MessageBox.Show("You need to fill all the player fields");
                return;
            }
            foreach (Team team in teamList)
            {
                foreach (Player player in team.GetPlayers)
                {
                    if (player.GetPlayerName().ToUpper().Equals(tbPlayerName.Text.ToUpper()))
                    {
                        MessageBox.Show("Player already exists");
                        return;
                    }

                }
            }
            Team currentTeam = getCurrentTeam();
            if (currentTeam == null)
            {
                return;
            }
            currentTeam.GetPlayers.Add(new Player(tbPlayerName.Text, tbPlayerNumber.Text, cbPlayerPosition.SelectedItem.ToString()));
            refreshTeamMember(cbTeam);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            Team currentTeam = getCurrentTeam();
            if (currentTeam.GetPlayers.Count<=11)
            {
                MessageBox.Show("Cannot Remove Player, 11 players is minimum");
                return;
            }
            foreach (Player player in currentTeam.GetPlayers)
            {
                if (player.ToString().Equals(lbTeamMember.SelectedItem))
                {
                    currentTeam.GetPlayers.Remove(player);
                    refreshTeamMember(cbTeam);
                    break;
                }
            }
        }
    }
}
