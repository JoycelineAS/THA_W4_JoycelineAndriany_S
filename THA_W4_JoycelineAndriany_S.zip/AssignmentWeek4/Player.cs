﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentWeek4
{
    internal class Player
    {
        private String playerName, playerNum, playerPos;

        public Player(string playerName, string playerNum, string playerPos)
        {
            this.playerName = playerName;
            this.playerNum = playerNum;
            this.playerPos = playerPos;
        }
        public String GetPlayerName() { return playerName; }
        public string GetPlayerNum() { return playerNum; }
        public string GetPlayerPos() { return playerPos; }

        public override string ToString()
        {
            return "("+this.playerNum+") "+this.playerName+", "+this.playerPos;
        }
    }
}
