﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentWeek4
{
    internal class Team
    {
        private string teamName;
        private string teamCountry;
        private string teamCity;
        private List<Player> Players;

        public Team(string teamName, string teamCountry, string teamCity, List<Player> players)
        {
            this.teamName = teamName;
            this.teamCountry = teamCountry;
            this.teamCity = teamCity;
            Players = players;
        }
        public Team(string teamName, string teamCountry, string teamCity)
        {
            this.teamName = teamName;
            this.teamCountry = teamCountry;
            this.teamCity = teamCity;
            Players = new List<Player>();
        }
        public string TeamName { get { return teamName; } }
        public string TeamCountry { get { return teamCountry; } }
        public List<Player> GetPlayers { get { return Players; } }
    }
}
